# Stub __init__.py for sympy.functions.elementary
